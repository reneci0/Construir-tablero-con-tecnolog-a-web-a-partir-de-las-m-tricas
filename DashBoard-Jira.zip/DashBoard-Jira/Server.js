const express = require("express");
const axios = require("axios");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.static("public"));

const JIRA_URL = "https://qcarlosr28-1775081206961.atlassian.net";
const EMAIL = "qcarlosr28@gmail.com";
const TOKEN = "ATATT3xFfGF0nnJMVAsK6em5xkb5SQNtI26NnZL3IhrhVAYEx9zpnZqNFWj_JEF18WFFGACCaHynMqFO4a9XaiEIPtsUNTeKsxO2dp--r-0l9tDpDyxDdRjY0IBDHQ5Vh36UsSj6aDxxpsABuZOn8N3lHo4t6XaFS9tGNWJZFeHVfFlX875Iq_4=BF904541"; // ⚠️ pon tu token

const auth = Buffer.from(`${EMAIL}:${TOKEN}`).toString("base64");

app.get("/api/issues", async (req, res) => {
  try {
    const jql = "project = CT AND created >= -30d ORDER BY created DESC";

    const response = await axios.get(
      `${JIRA_URL}/rest/api/3/search/jql`,
      {
        headers: {
          Authorization: `Basic ${auth}`,
          Accept: "application/json"
        },
        params: {
          jql,
          maxResults: 50,
          fields: "summary,status,customfield_10092,customfield_10126,created,updated"
        }
      }
    );

    res.json(response.data);

  } catch (error) {
    console.error(error.response?.data || error.message);
    res.status(500).json({ error: "Error al obtener datos de Jira" });
  }
});

app.listen(3000, () => {
  console.log("Servidor corriendo en http://localhost:3000");
});