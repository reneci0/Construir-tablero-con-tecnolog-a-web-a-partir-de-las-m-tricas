const API_URL = "http://localhost:3000/api/issues";

let chartCategorias;
let chartEstados;
let chartTiempo;

let animacionEjecutada = false;


// ============================
async function obtenerDatos() {
    try {
        const res = await fetch(API_URL);
        const data = await res.json();
        return data.issues;
    } catch (error) {
        console.error("Error:", error);
        return [];
    }
}

// ============================

function procesarDatos(issues) {

    const categoriasGasto = {};
    const estados = {
        Aprobadas: 0,
        "En proceso": 0,
        Rechazadas: 0
    };

    const tiempos = [];

    issues.forEach(issue => {
        const f = issue.fields;

        // CATEGORÍA (GASTO)
        // -----------------------
        const categoria = f.customfield_10126?.value || "Otros";
        const monto = f.customfield_10092 || 0;

        categoriasGasto[categoria] = (categoriasGasto[categoria] || 0) + monto;

        // -----------------------
        // ESTADOS (AGRUPADOS)
        // -----------------------
        const estado = f.status?.name || "";

        if (
            estado.includes("Aprobada") ||
            estado.includes("Compra Completada")
        ) {
            estados.Aprobadas++;
        }
        else if (
            estado.includes("Rechazada")
        ) {
            estados.Rechazadas++;
        }
        else {
            estados["En proceso"]++;
        }

        // -----------------------
        // TIEMPOS
        // -----------------------
        const created = new Date(f.created);
        const updated = new Date(f.updated);

        const horas = (updated - created) / (1000 * 60 * 60);

        tiempos.push({
            key: issue.key,
            tiempo: horas.toFixed(2)
        });
    });

    return { categoriasGasto, estados, tiempos };
}

// ============================
// BARRAS → GASTOS
// ============================
function renderCategorias(data) {
    const ctx = document.getElementById("graficaCategorias");

    if (chartCategorias) chartCategorias.destroy();

    chartCategorias = new Chart(ctx, {
        type: "bar",
        data: {
            labels: Object.keys(data),
            datasets: [{
                label: "Gasto total",
                data: Object.values(data),
                backgroundColor: "#3b82f6"
            }]
        },
        options: {
            plugins: {
                legend: { display: false }
            }
        }
    });
}

// ============================
// PASTEL → ESTADOS
// ============================
function renderEstados(data) {
    const ctx = document.getElementById("graficaEstados");

    if (chartEstados) chartEstados.destroy();

    chartEstados = new Chart(ctx, {
        type: "pie",
        data: {
            labels: Object.keys(data),
            datasets: [{
                data: Object.values(data),
                backgroundColor: [
                    "#22c55e", // aprobado
                    "#facc15", // proceso
                    "#ef4444"  // rechazado
                ]
            }]
        }
    });
}

// ============================
// TIEMPOS (ANIMADO)
// ============================
async function renderTiempo(tiempos) {

    const ctx = document.getElementById("graficaTiempo");

    if (chartTiempo) chartTiempo.destroy();

    chartTiempo = new Chart(ctx, {
        type: "bar",
        data: {
            labels: [],
            datasets: [{
                label: "Horas",
                data: [],
                backgroundColor: "#8b5cf6"
            }]
        },
        options: {
            animation: false
        }
    });

    if (animacionEjecutada) return;
    animacionEjecutada = true;

    for (let i = 0; i < tiempos.length; i++) {
        chartTiempo.data.labels.push(tiempos[i].key);
        chartTiempo.data.datasets[0].data.push(tiempos[i].tiempo);
        chartTiempo.update();

        await new Promise(r => setTimeout(r, 300));
    }
}


// ============================
async function actualizarDashboard() {
    const issues = await obtenerDatos();
    const datos = procesarDatos(issues);

    console.log("DATOS:", datos);

    renderCategorias(datos.categoriasGasto);
    renderEstados(datos.estados);
    renderTiempo(datos.tiempos);
}

actualizarDashboard();